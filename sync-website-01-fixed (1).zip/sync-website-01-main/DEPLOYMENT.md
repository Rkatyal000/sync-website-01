# SYNC Media — Deployment Guide

This document covers running the project locally, deploying to production,
and the uptime commitment for each environment.

## What gets deployed

Two independent units are deployed:

| Unit | Source | Technology |
|------|--------|------------|
| **Frontend SPA** | `frontend/` | React 19 + Vite — builds to static HTML/JS/CSS |
| **Backend API** | `backend-bun/` | Bun + TypeScript + Hono — the **production backend** |

> **Important:** `backend/` (FastAPI/Python) is kept for local development and
> CI smoke-testing only. **Do not deploy the Python backend to production.**
> Use `backend-bun/` for all production and staging environments.

---

## Uptime requirements

| Environment | Target uptime | Max monthly downtime | Monitoring |
|-------------|:------------:|:--------------------:|------------|
| Production  | **99.9 %**   | ~44 min/month        | Pingdom + PagerDuty on-call |
| Staging     | **95 %**     | ~36 hr/month         | UptimeRobot ping only |

SLO clock starts from first production deployment. Any degradation of the
`/healthz` endpoint for > 1 minute counts as downtime.

---

## Recommended infrastructure

|              | Staging                            | Production                                                              |
|--------------|------------------------------------|-------------------------------------------------------------------------|
| **Frontend** | Cloudflare Pages (preview branch)  | Cloudflare Pages (main branch) — CDN, HTTP/3, immutable asset cache    |
| **Backend**  | Railway / Fly.io (1 instance)      | Fly.io or Railway — 2 instances behind LB, auto-scale 2→10 on CPU 60% |
| **Database** | MongoDB Atlas M0 (free)            | MongoDB Atlas M10+ replica set, daily snapshots, region-pinned to backend |
| **DNS / TLS**| Cloudflare proxied                 | Cloudflare proxied, HSTS enabled                                        |
| **Logs**     | stdout (Railway dashboard)         | Loki + Grafana **or** Datadog                                           |
| **Alerts**   | —                                  | Pingdom uptime + PagerDuty on-call rotation                             |

---

## Environment variables

### `frontend/.env`

| Variable            | Required | Description                                              |
|---------------------|:--------:|----------------------------------------------------------|
| `VITE_BACKEND_URL`  | yes      | Public URL of the Bun backend, no trailing slash. The frontend appends `/api`. Example: `https://api.syncmedia.io` |

### `backend-bun/.env`

| Variable             | Required | Default     | Description                                                        |
|----------------------|:--------:|-------------|--------------------------------------------------------------------|
| `MONGO_URL`          | yes      | —           | MongoDB Atlas connection string                                    |
| `DB_NAME`            | yes      | —           | MongoDB database name (e.g. `sync_prod`)                          |
| `HOST`               | no       | `0.0.0.0`   | Bind interface                                                     |
| `PORT`               | no       | `8001`      | Listen port                                                        |
| `LOG_LEVEL`          | no       | `info`      | `debug` / `info` / `warn` / `error`                               |
| `CORS_ORIGINS`       | no       | `*`         | Comma-separated allowed origins. **Set explicitly in production.** |
| `LEADS_EXPORT_TOKEN` | **yes in prod** | — | Shared secret for `GET /api/leads/export`. Without this the export is open to anyone. |

---

## Local development

### Frontend

```bash
cd frontend
cp .env.example .env          # set VITE_BACKEND_URL=http://localhost:8001
npm install
npm run dev                   # Vite dev server → http://localhost:3000
```

### Backend (Bun — recommended)

```bash
cd backend-bun
cp .env.example .env          # set MONGO_URL and DB_NAME
bun install
bun run dev                   # hot-reload → http://localhost:8001
```

### Backend (FastAPI — local / legacy only)

```bash
cd backend
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
uvicorn server:app --host 0.0.0.0 --port 8001 --reload
```

---

## Production deployment (step-by-step)

### 1. Deploy the database

Create a **MongoDB Atlas M10** cluster in the same region as your backend host.
Enable daily snapshots. Copy the connection string — you'll need it for step 2.

### 2. Deploy the Bun backend

**Using Fly.io (recommended):**

```bash
cd backend-bun
fly launch --name sync-api --region lhr   # pick region closest to your users
fly secrets set MONGO_URL="<atlas-connection-string>"
fly secrets set DB_NAME="sync_prod"
fly secrets set CORS_ORIGINS="https://syncmedia.io"
fly secrets set LEADS_EXPORT_TOKEN="$(openssl rand -hex 32)"
fly deploy
```

Confirm the backend is healthy:

```bash
curl https://sync-api.fly.dev/healthz
# → {"ok":true,"uptimeSec":...,"mongoOk":true}
```

### 3. Deploy the frontend

**Using Cloudflare Pages:**

1. Connect the GitHub repo to Cloudflare Pages.
2. Set build command: `cd frontend && npm ci && npm run build`
3. Set output directory: `frontend/build`
4. Add environment variable: `VITE_BACKEND_URL=https://sync-api.fly.dev`
5. Deploy. Cloudflare Pages will deploy every push to `main` automatically.

### 4. Configure DNS

Point your domain at Cloudflare Pages. Enable "Proxied" mode for the frontend.
For the backend, use a `CNAME` to `sync-api.fly.dev` (or the platform URL).

---

## Docker (self-hosted / Kubernetes)

The Bun backend ships a multi-stage Dockerfile:

```bash
cd backend-bun
docker build -t sync-api .
docker run -p 8001:8001 \
  -e MONGO_URL="..." \
  -e DB_NAME="sync_prod" \
  -e LEADS_EXPORT_TOKEN="..." \
  sync-api
```

For Kubernetes, use the Dockerfile as the image and inject secrets via
`Secret` → `envFrom`.

---

## Monitoring checklist (production)

- [ ] Pingdom (or Better Uptime) pinging `GET /healthz` every 1 min
- [ ] PagerDuty alert if uptime check fails for > 2 consecutive probes
- [ ] MongoDB Atlas alerts: disk > 80%, connections > 80%, replication lag > 60s
- [ ] Fly.io / Railway CPU and memory alerts
- [ ] Log aggregation (Loki / Datadog) with `level=error` alert
- [ ] Monthly review of 99.9% SLO adherence
