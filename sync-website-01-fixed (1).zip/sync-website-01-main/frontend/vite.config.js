import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import path from "node:path";

/**
 * Vite configuration for the SYNC media frontend.
 *
 * - `@/...` path alias points to `src/`.
 * - `VITE_*` env vars are exposed to client code via import.meta.env.
 * - Dev server on 0.0.0.0:3000 for container / preview proxy compatibility.
 */
export default defineConfig({
  plugins: [react()],

  resolve: {
    alias: {
      "@": path.resolve(__dirname, "src"),
    },
  },

  server: {
    host: "0.0.0.0",
    port: 3000,
    strictPort: true,
    hmr: {
      clientPort: 443,
      protocol: "wss",
    },
    allowedHosts: true,
    watch: {
      ignored: [
        "**/node_modules/**",
        "**/.git/**",
        "**/build/**",
        "**/dist/**",
        "**/coverage/**",
      ],
    },
  },

  preview: {
    host: "0.0.0.0",
    port: 3000,
    strictPort: true,
    allowedHosts: true,
  },

  build: {
    outDir: "build",
    sourcemap: false,
    chunkSizeWarningLimit: 1200,
  },
});
